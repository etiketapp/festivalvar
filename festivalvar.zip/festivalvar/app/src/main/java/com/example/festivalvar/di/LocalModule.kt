package com.example.festivalvar.di

import org.koin.dsl.module.module

val localModule = module {

}