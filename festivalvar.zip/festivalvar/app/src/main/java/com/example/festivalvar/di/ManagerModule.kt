package com.example.festivalvar.di

import org.koin.dsl.module.module

val managerModule = module {/*
    single { RemoteDataManager() }
    single { LocalDataManager() }
    single { DataManager(get(), get()) }*/
}