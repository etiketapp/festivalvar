package com.example.festivalvar.data.local


interface ILocalDataManager {

}