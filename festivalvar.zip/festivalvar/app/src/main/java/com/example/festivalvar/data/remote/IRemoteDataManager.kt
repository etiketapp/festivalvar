package com.example.festivalvar.data.remote

import okhttp3.MultipartBody
import okhttp3.RequestBody

interface IRemoteDataManager {}