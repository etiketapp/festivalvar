package com.example.festivalvar.di

import org.koin.dsl.module.module

val remoteModule = module {
   // factory { createWebService<ISliderService>() }
}