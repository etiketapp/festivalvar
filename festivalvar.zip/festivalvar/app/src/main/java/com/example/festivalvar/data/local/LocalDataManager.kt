package com.example.festivalvar.data.local

class LocalDataManager : ILocalDataManager {

}